<template>
  <div id="app">
    <header>
      <h1>Kafka Consumer Messages</h1>
    </header>
    <div id="messages" class="messages">
      <div v-for="(message, index) in messages" :key="index" class="message">
        {{ message }}
      </div>
    </div>
  </div>
</template>

<script>
import io from "socket.io-client";

export default {
  name: "App",
  data() {
    return {
      messages: [],  // Array to hold incoming messages
      socket: null,  // Socket.io instance
    };
  },
  created() {
    // Connect to the Kafka Consumer Node.js server using Socket.io
    this.socket = io("http://localhost:3000");

    // Listen for Kafka messages from the server
    this.socket.on("kafkaMessage", (message) => {
      // Add the received message to the messages array
      this.messages.push(JSON.stringify(message, null, 2));
      // Auto-scroll to the latest message
      this.$nextTick(() => {
        const messagesDiv = this.$el.querySelector("#messages");
        messagesDiv.scrollTop = messagesDiv.scrollHeight;
      });
    });
  },
  beforeUnMount() {
    // Disconnect the socket when the component is destroyed
    if (this.socket) {
      this.socket.disconnect();
    }
  },
};
</script>

<style>
body {
  font-family: Arial, sans-serif;
  margin: 20px;
}
#messages {
  border: 1px solid #ccc;
  padding: 10px;
  max-height: 500px;
  overflow-y: scroll;
  background-color: #f9f9f9;
}
.message {
  padding: 5px;
  margin: 5px 0;
  border-bottom: 1px solid #ddd;
  white-space: pre-wrap; /* Preserve whitespace and formatting */
}
</style>
