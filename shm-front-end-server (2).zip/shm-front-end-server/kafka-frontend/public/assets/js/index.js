

$(function() {
    "use strict";

     // chart 1
	 
		  var ctx = document.getElementById('chart1').getContext('2d');
			var myChart = new Chart(ctx, {
				type: 'line',
				data: {
					labels: ["SG1", "SG2", "SG3", "SG4", "SG5", "SG6", "SG7", "SG8", "SG9", "SG10"],
					datasets: [{
						label: 'Today Reading',
						data: [3, 3, 8, 5, 7, 4, 6, 4, 6, 3],
						backgroundColor: '#fff',
						borderColor: "transparent",
						pointRadius :"0",
						borderWidth: 3
					}, {
						label: 'Yesterday Reading',
						data: [7, 5, 14, 7, 12, 6, 10, 6, 11, 5],
						backgroundColor: "rgba(255, 255, 255, 0.25)",
						borderColor: "transparent",
						pointRadius :"0",
						borderWidth: 1
					}]
				},
			options: {
				maintainAspectRatio: false,
				legend: {
				  display: false,
				  labels: {
					fontColor: '#ddd',  
					boxWidth:40
				  }
				},
				tooltips: {
				  displayColors:false
				},	
			  scales: {
				  xAxes: [{
					ticks: {
						beginAtZero:true,
						fontColor: '#ddd'
					},
					gridLines: {
					  display: true ,
					  color: "rgba(221, 221, 221, 0.08)"
					},
				  }],
				   yAxes: [{
					ticks: {
						beginAtZero:true,
						fontColor: '#ddd'
					},
					gridLines: {
					  display: true ,
					  color: "rgba(221, 221, 221, 0.08)"
					},
				  }]
				 }

			 }
			});  
	
    // chart 2

		var ctx = document.getElementById("chart2").getContext('2d');
			var myChart = new Chart(ctx, {
				type: 'doughnut',
				data: {
					labels: ["Direct", "Affiliate", "E-mail", "Other"],
					datasets: [{
						backgroundColor: [
							"#ffffff",
							"rgba(255, 255, 255, 0.70)",
							"rgba(255, 255, 255, 0.50)",
							"rgba(255, 255, 255, 0.20)"
						],
						data: [5856, 2602, 1802, 1105],
						borderWidth: [0, 0, 0, 0]
					}]
				},
			options: {
				maintainAspectRatio: false,
			   legend: {
				 position :"bottom",	
				 display: false,
				    labels: {
					  fontColor: '#ddd',  
					  boxWidth:15
				   }
				}
				,
				tooltips: {
				  displayColors:false
				}
			   }
			});
		
   });	


// Strain Gauge Chart
   const ctx1 = document.getElementById('realTimeChartForStrainGauge').getContext('2d');
	const realTimeChartForStrainGauge = new Chart(ctx1, {
	   type: 'line',
	   data: {
		   labels: [], // Initially empty
		   datasets: [
			{
				label: 'Sensor 1',  // Label for the first line
				data: [],  // Data points for the first line
				borderColor: 'rgba(75, 192, 192, 1)',  // Color of the first line
				fill: false,  // Set to false to avoid filling under the line
			},
			{
				label: 'Sensor 2',  // Label for the second line
				data: [],  // Data points for the second line
				borderColor: 'rgba(255, 99, 132, 1)',  // Color of the second line
				fill: false,  // Set to false to avoid filling under the line
			},
			{
				label: 'Sensor 3',  // Label for the third line
				data: [],  // Data points for the third line
				borderColor: 'rgba(54, 162, 235, 1)',  // Color of the third line
				fill: false,  // Set to false to avoid filling under the line
			}
		   ]
	   },
	   options: {
		maintainAspectRatio: false,
		legend: {
		  display: true,
		  labels: {
			fontColor: '#ddd',
			boxWidth:40
		  }
		},
		tooltips: {
		  displayColors:true
		},
		scales: {
			xAxes: [{
				ticks: {
					beginAtZero:true,
					fontColor: '#ddd'
				},
				gridLines: {
				  display: true ,
				  color: "rgba(221, 221, 221, 0.08)"
				},
			  }],
			  yAxes: [{
				ticks: {
					beginAtZero:true,
					fontColor: '#ddd'
				},
				gridLines: {
				  display: true ,
				  color: "rgba(221, 221, 221, 0.08)"
				},
			  }]
		   }
	   }
   });

// Temperature Chart
   const ctx2 = document.getElementById('realTimeChartForTemperature').getContext('2d');
   const realTimeChartForTemperature = new Chart(ctx2, {
	  type: 'line',
	  data: {
		  labels: [], // Initially empty
		  datasets: [{
			  label: 'Real-Time Data',
			  data: [], // Initially empty
			  //backgroundColor: '#fff',
			   borderColor: "rgb(255,255,255)",
			   pointRadius :"0",
			   borderWidth: 3, 
			   fill: false // avoid filling underlines
		  }]
	  },
	  options: {
	   maintainAspectRatio: false,
	   legend: {
		 display: false,
		//  labels: {
		//    fontColor: '#ddd',
		//    borderColor: "rgb(255,255,255)",
		//    boxWidth:2
		//  }
	   },
	   tooltips: {
		 displayColors:true
	   },
	   scales: {
		   xAxes: [{
			   ticks: {
				   beginAtZero:true,
				   fontColor: '#ddd'
			   },
			   gridLines: {
				 display: true ,
				 color: "rgba(221, 221, 221, 0.08)"
			   },
			 }],
			 yAxes: [{
			   ticks: {
				   beginAtZero:true,
				   fontColor: '#ddd'
			   },
			   gridLines: {
				 display: true ,
				 color: "rgba(221, 221, 221, 0.08)"
			   },
			 }]
		  }
	  }
  });

  const ctx3 = document.getElementById('realTimeChartForAccelerometer').getContext('2d');
  const realTimeChartForAccelerometer = new Chart(ctx3, {
	 type: 'line',
	 data: {
		 labels: [], // Initially empty
		 datasets: [
			{
				label: 'Sensor 1',  // Label for the first line
				data: [],  // Data points for the first line
				borderColor: 'rgba(75, 192, 192, 1)',  // Color of the first line
				fill: false,  // Set to false to avoid filling under the line
			},
			{
				label: 'Sensor 2',  // Label for the second line
				data: [],  // Data points for the second line
				borderColor: 'rgba(255, 99, 132, 1)',  // Color of the second line
				fill: false,  // Set to false to avoid filling under the line
			},
			{
				label: 'Sensor 3',  // Label for the third line
				data: [],  // Data points for the third line
				borderColor: 'rgba(54, 162, 235, 1)',  // Color of the third line
				fill: false,  // Set to false to avoid filling under the line
			}
		 ]
	 },
	 options: {
	  maintainAspectRatio: false,
	  legend: {
		display: true,
		labels: {
		  fontColor: '#ddd',
		  boxWidth:40
		}
	  },
	  tooltips: {
		displayColors:true
	  },
	  scales: {
		  xAxes: [{
			  ticks: {
				  beginAtZero:true,
				  fontColor: '#ddd'
			  },
			  gridLines: {
				display: true ,
				color: "rgba(221, 221, 221, 0.08)"
			  },
			}],
			yAxes: [{
			  ticks: {
				  beginAtZero:true,
				  fontColor: '#ddd'
			  },
			  gridLines: {
				display: true ,
				color: "rgba(221, 221, 221, 0.08)"
			  },
			}]
		 }
	 }
 });

// Humidity Chart
 const ctx4 = document.getElementById('realTimeChartForHumidity').getContext('2d');
 const realTimeChartForHumidity = new Chart(ctx4, {
	type: 'line',
	data: {
		labels: [], // Initially empty
		datasets: [{
			label: 'Real-Time Data',
			data: [], // Initially empty
			borderColor: "rgb(255,255,255)",
			pointRadius :"0",
			borderWidth: 3, 
			fill: false // avoid filling underlines
		}]
	},
	options: {
	 maintainAspectRatio: false,
	 legend: {
	   display: false,
	   labels: {
		 fontColor: '#ddd',
		 boxWidth:40
	   }
	 },
	 tooltips: {
	   displayColors:true
	 },
	 scales: {
		 xAxes: [{
			 ticks: {
				 beginAtZero:true,
				 fontColor: '#ddd'
			 },
			 gridLines: {
			   display: true ,
			   color: "rgba(221, 221, 221, 0.08)"
			 },
		   }],
		   yAxes: [{
			 ticks: {
				 beginAtZero:false,
				 fontColor: '#ddd'
			 },
			 gridLines: {
			   display: true ,
			   color: "rgba(221, 221, 221, 0.08)"
			 },
		   }]
		}
	}
});

// humidity histogram
function generateHumidityHistogram(){
	// Create bins for the histogram (e.g., 5 bins for this data)
    var bins = [30, 32, 34, 36, 38, 40];
    var counts = new Array(bins.length - 1).fill(0);  // Initialize bins

    // Count occurrences of data in each bin
    realTimeChartForHumidity.data.datasets[0].data.forEach(function(value) {
        for (var i = 0; i < bins.length - 1; i++) {
            if (value >= bins[i] && value < bins[i+1]) {
                counts[i]++;
                break;
            }
        }
    });

    // Render the chart
    var humidityChart = document.getElementById('histogramForHumidity').getContext('2d');
    var humidityHistogram = new Chart(humidityChart, {
        type: 'bar',  // Using 'bar' type to simulate a histogram
        data: {
            labels: bins.slice(0, -1).map(function(bin, i) {
                return bins[i] + ' - ' + bins[i+1];  // Bin labels
            }),
            datasets: [{
                label: 'Frequency',
                data: counts,  // Frequency of data in each bin
                backgroundColor: 'rgba(75, 192, 192, 0.6)',  // Bar color
                borderColor: 'rgba(75, 192, 192, 1)',  // Bar border color
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true  // Ensure the y-axis starts at 0
                }
            }
        }
    });

}

    
   
   function addTempData(label, data) {
		if (realTimeChartForTemperature.data.datasets[0].data.length >= 30)
		{
			// if the length exceeds 30 data point, remove the first element
			realTimeChartForTemperature.data.datasets[0].data.shift();
			realTimeChartForTemperature.data.labels.shift();
		}
		realTimeChartForTemperature.data.labels.push(label);
		realTimeChartForTemperature.data.datasets[0].data.push(data);
	   updatingWarningTempTable(realTimeChartForTemperature.data.labels, realTimeChartForTemperature.data.datasets[0].data )
	   realTimeChartForTemperature.update();
	   
   }

   function addHumidityData(label, data) {
	if (realTimeChartForHumidity.data.datasets[0].data.length >= 30)
	{
		// if the length exceeds 30 data point, remove the first element
		realTimeChartForHumidity.data.datasets[0].data.shift();
		realTimeChartForHumidity.data.labels.shift();
	}
	realTimeChartForHumidity.data.labels.push(label);
	realTimeChartForHumidity.data.datasets[0].data.push(data);
   updatingWarningHumidityTable(realTimeChartForHumidity.data.labels, realTimeChartForHumidity.data.datasets[0].data )
   realTimeChartForHumidity.update();
	}

	function addSimulatedStrainGaugeData(sensor, label, value)
	{
		if (realTimeChartForStrainGauge.data.labels.length >= 30)
		{
			realTimeChartForStrainGauge.data.labels.shift();
		}
		if (realTimeChartForStrainGauge.data.datasets[sensor].data.length >= 30)
		{
					// if the length exceeds 30 data point, remove the first element
					realTimeChartForStrainGauge.data.datasets[sensor].data.shift();
		}

		if (sensor === 0) {
			realTimeChartForStrainGauge.data.labels.push(label);
		}
		realTimeChartForStrainGauge.data.datasets[sensor].data.push(value);
		console.log("update strain gauge data for sensor " + sensor);
		updatingWarningTable(realTimeChartForStrainGauge.data.labels, realTimeChartForStrainGauge.data.datasets[sensor].data, sensor)
		realTimeChartForStrainGauge.update();
	}

	function addSimulatedAccelerometerData(sensor, label, value)
	{
		if (realTimeChartForAccelerometer.data.labels.length >= 30)
		{
			realTimeChartForAccelerometer.data.labels.shift();
		}
		if (realTimeChartForAccelerometer.data.datasets[sensor].data.length >= 30)
		{
					// if the length exceeds 30 data point, remove the first element
					realTimeChartForAccelerometer.data.datasets[sensor].data.shift();
		}

		if (sensor === 0) {
			realTimeChartForAccelerometer.data.labels.push(label);
		}
		realTimeChartForAccelerometer.data.datasets[sensor].data.push(value);
		updatingWarningAccelerometerTable(realTimeChartForAccelerometer.data.labels, realTimeChartForAccelerometer.data.datasets[sensor].data, sensor )
		realTimeChartForAccelerometer.update();
	}

   // Simulating real-time data update
   setInterval(() => {
	   const now = new Date();
	   addTempData(now.toLocaleTimeString(), Math.random() * 2 + 20);
	   addHumidityData(now.toLocaleTimeString(), Math.random() * 10 + 30);

	   let numberOfSensors = 3;
	   let currentTime = now.toLocaleTimeString();
	   for (let i= 0; i< numberOfSensors; i++)
	   {
		addSimulatedStrainGaugeData(i, currentTime, Math.random() * 2);
		addSimulatedAccelerometerData(i, currentTime, Math.random() * 2);
	   }

   }, 500); // Update every 200 mili second

   function addRowToSgTable(timestamp, value, id, variance) {
	// Get the reference to the table body
	const table = document.getElementById("sg-warning").getElementsByTagName('tbody')[0];
  
	// Insert a new row at the end of the table
	const newRow = table.insertRow();
  
	// Insert new cells (columns) in the new row
	const cell1 = newRow.insertCell();
	const cell2 = newRow.insertCell();
	const cell3 = newRow.insertCell();
	const cell4 = newRow.insertCell();
  
	// Add content to the new cells
	cell1.textContent = timestamp;
	cell2.textContent = parseFloat(value.toFixed(6));
	cell3.textContent = id;
	cell4.textContent = parseFloat(variance.toFixed(2));
    }

	function addRowToTempTable(timestamp, value, id, variance) {
		// Get the reference to the table body
		const table = document.getElementById("temp-warning").getElementsByTagName('tbody')[0];
	  
		// Insert a new row at the end of the table
		const newRow = table.insertRow();
	  
		// Insert new cells (columns) in the new row
		const cell1 = newRow.insertCell();
		const cell2 = newRow.insertCell();
		const cell3 = newRow.insertCell();
		const cell4 = newRow.insertCell();
	  
		// Add content to the new cells
		cell1.textContent = timestamp;
		cell2.textContent = parseFloat(value.toFixed(6));
		cell3.textContent = id;
		cell4.textContent = parseFloat(variance.toFixed(2));
		}

		function addRowToAccelerometerTable(timestamp, value, id, variance) {
			// Get the reference to the table body
			const table = document.getElementById("acc-warning").getElementsByTagName('tbody')[0];
		  
			// Insert a new row at the end of the table
			const newRow = table.insertRow();
		  
			// Insert new cells (columns) in the new row
			const cell1 = newRow.insertCell();
			const cell2 = newRow.insertCell();
			const cell3 = newRow.insertCell();
			const cell4 = newRow.insertCell();
		  
			// Add content to the new cells
			cell1.textContent = timestamp;
			cell2.textContent = parseFloat(value.toFixed(6));
			cell3.textContent = id;
			cell4.textContent = parseFloat(variance.toFixed(2));
			}

			function addRowToHumidityTable(timestamp, value, id, variance) {
				// Get the reference to the table body
				const table = document.getElementById("humidity-warning").getElementsByTagName('tbody')[0];
			  
				// Insert a new row at the end of the table
				const newRow = table.insertRow();
			  
				// Insert new cells (columns) in the new row
				const cell1 = newRow.insertCell();
				const cell2 = newRow.insertCell();
				const cell3 = newRow.insertCell();
				const cell4 = newRow.insertCell();
			  
				// Add content to the new cells
				cell1.textContent = timestamp;
				cell2.textContent = parseFloat(value.toFixed(6));
				cell3.textContent = id;
				cell4.textContent = parseFloat(variance.toFixed(2));
				}


	// This part is for demo only
	function calculateMean(data) {
		const sum = data.reduce((acc, value) => acc + value, 0);
		return sum / data.length;
	  }
	  
	  // Function to calculate standard deviation of an array
	  function calculateStandardDeviation(data, mean) {
		const squaredDifferences = data.map(value => Math.pow(value - mean, 2));
		const variance = calculateMean(squaredDifferences);
		return Math.sqrt(variance);
	  }
	  
	  // Function to calculate z-score for each data point in the array
	  function calculateZScores(data) {
		const mean = calculateMean(data);
		const standardDeviation = calculateStandardDeviation(data, mean);
	  
		return data.map(value => (value - mean) / standardDeviation);
	  }
	  
	  function updatingWarningTable(label, data, sensor) 
	  {
		console.log("Updating Strain gauge warning table");
		const zScores = calculateZScores(data);
		//console.log("z scores is " + zScores[zScores.length -1]);

		if (zScores[zScores.length -1] > 1.5 || zScores[zScores.length -1] < -1.5)
		{
			addRowToSgTable(label[zScores.length -1], data[zScores.length -1], sensor, zScores[zScores.length -1]);
		}
	  }

	  function updatingWarningAccelerometerTable(label, data, sensor) 
	  {
		console.log("Updating accelerometer warning table");
		const zScores = calculateZScores(data);
		//console.log("z scores is " + zScores[zScores.length -1]);

		if (zScores[zScores.length -1] > 1.5 || zScores[zScores.length -1] < -1.5)
		{
			addRowToAccelerometerTable(label[zScores.length -1], data[zScores.length -1], sensor, zScores[zScores.length -1]);
		}
	  }

	  function updatingWarningHumidityTable(label, data) 
	  {
		console.log("Updating humidity warning table");
		const zScores = calculateZScores(data);
		//console.log("z scores is " + zScores[zScores.length -1]);

		if (zScores[zScores.length -1] > 1.5 || zScores[zScores.length -1] < -1.5)
		{
			addRowToHumidityTable(label[zScores.length -1], data[zScores.length -1], 1, zScores[zScores.length -1]);
		}
	  }

	  function updatingWarningTempTable(label, data) 
	  {
		console.log("Updating temperature warning table");
		const zScores = calculateZScores(data);
		//console.log("z scores is " + zScores[zScores.length -1]);

		if (zScores[zScores.length -1] > 1.5 || zScores[zScores.length -1] < -1.5)
		{
			addRowToTempTable(label[zScores.length -1], data[zScores.length -1], 1, zScores[zScores.length -1]);
		}
	  }


   