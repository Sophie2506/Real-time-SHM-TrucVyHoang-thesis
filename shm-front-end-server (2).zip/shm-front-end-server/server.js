const { Kafka } = require('kafkajs');
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const { SchemaRegistry, SchemaType } = require('@kafkajs/confluent-schema-registry');
const cors = require('cors');

// Kafka and Schema Registry configuration
const kafka = new Kafka({
  clientId: 'kafka-consumer',
  brokers: ['localhost:9092', 'localhost:9093', 'localhost:9094'],  
});

const schemaRegistry = new SchemaRegistry({
  host: 'http://localhost:8081', // Schema Registry URL
});

const groupId = 'express-consumer'; 
const consumer = kafka.consumer({ groupId });

// Express setup
const app = express();
app.use(cors());
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*", 
    methods: ["GET", "POST"],
  },
});


// Kafka consumer function
const runKafkaConsumer = async () => {
  await consumer.connect();
  await consumer.subscribe({ topics: ['sensor_sg', 'sensor_acc'], fromBeginning: true });

  await consumer.run({
    eachMessage: async ({ topic, partition, message }) => {
      try {
        // Deserialize the message key (String)
        const messageKey = message.key ? message.key.toString() : 'None';
        
        // Deserialize the Avro-encoded message value using Schema Registry
        const decodedValue = await schemaRegistry.decode(message.value);

        console.log(`Received message: Key = ${messageKey}, Value =`, decodedValue);
        
        // Emit the deserialized message to the frontend via Socket.io
        io.emit('kafkaMessage', { key: messageKey, value: decodedValue });
      } catch (err) {
        console.error(`Error processing message: ${err.message}`);
      }
    },
  });
};
runKafkaConsumer().catch(console.error);

// Handle process termination gracefully
process.on('SIGINT', async () => {
  console.log('Disconnecting consumer...');
  await consumer.disconnect();
  process.exit();
});

// Start the server on port 3000
const PORT = 3000;
server.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

// const textFrontEnd = document.getElementById("frontendData");
// textFrontEnd.textContent = dataFromServer;

//const topic = 'sensor_sg'; // strain gauge topic
